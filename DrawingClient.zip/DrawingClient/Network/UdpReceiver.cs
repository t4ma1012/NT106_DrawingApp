﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using SharedLib.Packets;
using SharedLib.Payloads;
using Newtonsoft.Json;

namespace DrawingClient.Network
{
    // ═══════════════════════════════════════════════════════
    // LẮNG NGHE GÓI UDP TỪ SERVER, DESERIALIZE VÀ RAISE EVENT
    // ═══════════════════════════════════════════════════════
    public class UdpReceiver : IDisposable
    {
        private UdpClient _udpClient;
        private CancellationTokenSource _cts;
        private Task _listenTask;
        private readonly int _port;
        private bool _disposed = false;

        public UdpReceiver(int localPort = 8889)
        {
            _port = localPort;
        }

        public void Start()
        {
            if (_listenTask != null && !_listenTask.IsCompleted) return;

            _udpClient = new UdpClient(_port);
            _cts = new CancellationTokenSource();
            _listenTask = Task.Run(() => ListenLoop(_cts.Token));
            Console.WriteLine($"[UdpReceiver] Đang lắng nghe UDP port {_port}...");
        }

        public void Stop()
        {
            _cts?.Cancel();
            _udpClient?.Close();
            Console.WriteLine("[UdpReceiver] Đã dừng.");
        }

        private void ListenLoop(CancellationToken token)
        {
            IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);

            while (!token.IsCancellationRequested)
            {
                try
                {
                    byte[] data = _udpClient.Receive(ref remoteEP);
                    ProcessPacket(data);
                }
                catch { break; }
            }
        }

        private void ProcessPacket(byte[] data)
        {
            try
            {
                Packet packet = Packet.Deserialize(data);
                string json = Encoding.UTF8.GetString(packet.Payload);

                // GIẢI PHÁP: Gói lệnh nào thì ép đúng kiểu của gói đó ở đây!
                switch (packet.Cmd)
                {
                    case CommandType.DRAW:
                    case CommandType.TEXT: // Text dùng chung DrawPayload
                        var drawPayload = JsonConvert.DeserializeObject<DrawPayload>(json);
                        NetworkEvents.RaiseDrawReceived(drawPayload);
                        break;

                    case CommandType.FLOOD_FILL:
                        var floodPayload = JsonConvert.DeserializeObject<FloodFillPayload>(json);
                        NetworkEvents.RaiseFloodFillReceived(floodPayload);
                        break;

                    case CommandType.LASER:
                        var laserPayload = JsonConvert.DeserializeObject<LaserPayload>(json);
                        NetworkEvents.RaiseLaserReceived(laserPayload);
                        break;

                    case CommandType.REACTION:
                        var reactionPayload = JsonConvert.DeserializeObject<ReactionPayload>(json);
                        NetworkEvents.RaiseReactionReceived(reactionPayload);
                        break;

                    case CommandType.CURSOR:
                        var cursorPayload = JsonConvert.DeserializeObject<CursorPayload>(json);
                        NetworkEvents.RaiseCursorReceived(cursorPayload);
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[UdpReceiver] Lỗi xử lý packet: {ex.Message}");
            }
        }

        public void Dispose()
        {
            if (!_disposed)
            {
                Stop();
                _udpClient?.Dispose();
                _cts?.Dispose();
                _disposed = true;
            }
        }
    }
}
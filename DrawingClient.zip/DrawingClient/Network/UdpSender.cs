﻿using System;
using System.Net.Sockets;
using System.Text;
using SharedLib.Packets;
using SharedLib.Payloads;
using Newtonsoft.Json;

namespace DrawingClient.Network
{
    // ═══════════════════════════════════════════════════════
    // GỬI GÓI TIN UDP LÊN SERVER SIÊU TỐC
    // ═══════════════════════════════════════════════════════
    public class UdpSender
    {
        private readonly UdpClient _udpClient;
        private readonly string _serverIp;
        private readonly int _serverPort;

        public UdpSender(string serverIp = "127.0.0.1", int port = 8889)
        {
            _serverIp = serverIp;
            _serverPort = port;
            _udpClient = new UdpClient();
        }

        // Hàm lõi: Đóng gói mọi thứ thành JSON và bắn đi
        private void SendPacket(CommandType cmd, object payload)
        {
            try
            {
                string json = JsonConvert.SerializeObject(payload);
                byte[] payloadBytes = Encoding.UTF8.GetBytes(json);
                Packet packet = new Packet { Cmd = cmd, Payload = payloadBytes };
                byte[] data = packet.Serialize();

                _udpClient.Send(data, data.Length, _serverIp, _serverPort);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[UdpSender] Lỗi gửi UDP: {ex.Message}");
            }
        }

        // Các hàm phơi ra ngoài cho MainForm gọi tới
        public void SendDraw(DrawPayload payload) => SendPacket(CommandType.DRAW, payload);
        public void SendFloodFill(FloodFillPayload payload) => SendPacket(CommandType.FLOOD_FILL, payload);
        public void SendCursor(CursorPayload payload) => SendPacket(CommandType.CURSOR, payload);
        public void SendLaser(LaserPayload payload) => SendPacket(CommandType.LASER, payload);
        public void SendReaction(ReactionPayload payload) => SendPacket(CommandType.REACTION, payload);

        public void Close()
        {
            _udpClient?.Close();
        }
    }
}